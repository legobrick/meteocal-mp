/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
require(['weather_app','backbone'],function(app, Backbone){
  "use strict";
//  var moveBtn = function($el){
//      $el.appendTo(PF('myschedule').jq.find('td').eq(0).append('<span class="fc-header-space"></span>')).show().find('.fa').css('padding-top', '.15em');
//  };
//  moveBtn(PF('new_event_button').jq);
//  var theButton = PF('new_event_button').jq.clone();
//    var cielcio = function(){
//        PF('myschedule').jq.on('remove', function(){
//            moveBtn(theButton.clone()); cielcio();
//        });
//  }; cielcio();
  app.start();
});

